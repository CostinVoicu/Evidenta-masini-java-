package com.wtzconsult.demo.models;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)

public class CarRequestModel {
    Long id;
    String brand;
    String model;
    String vin;
    Integer hp;
    String carburant;
    Integer nr_usi;
    Integer cc;
    Long optionsId;
}
