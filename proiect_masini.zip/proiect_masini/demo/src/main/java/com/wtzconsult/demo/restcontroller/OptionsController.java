package com.wtzconsult.demo.restcontroller;

import com.wtzconsult.demo.bo.Options;
import com.wtzconsult.demo.service.OptionsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/options")
@RequiredArgsConstructor

public class OptionsController {
    private final OptionsService optionsService;

    @PostMapping("createWithBody")
    public ResponseEntity<?> createOptions(@RequestBody Options options)
    {
        return ResponseEntity.ok(optionsService.createOptionsWithBody(options));
    }

    /*@GetMapping("/GetAllOptionsByExhaust")
    public ResponseEntity<?> getAllByOptions(@RequestParam String exhaust)
    {
        return  ResponseEntity.ok(optionsService.getAllByOptions(exhaust));
    }*/

}
