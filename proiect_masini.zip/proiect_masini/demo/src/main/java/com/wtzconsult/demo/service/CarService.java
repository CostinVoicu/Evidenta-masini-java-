package com.wtzconsult.demo.service;

import com.wtzconsult.demo.bo.Car;
import com.wtzconsult.demo.bo.Options;
import com.wtzconsult.demo.models.CarRequestModel;
import com.wtzconsult.demo.models.CarResponseModel;
import com.wtzconsult.demo.repository.CarRepository;
import com.wtzconsult.demo.repository.OptionsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CarService {

    private final CarRepository carRepository;
    private final OptionsRepository optionsRepository;

    public CarResponseModel createCarWithBody(CarRequestModel carRequestModel) {
        Options options = optionsRepository.findOptionsByIdOrElseThrow(carRequestModel.getOptionsId());
        Car newCar = new Car(null, carRequestModel.getBrand(), carRequestModel.getModel(), carRequestModel.getVin(), carRequestModel.getHp(), carRequestModel.getCarburant(), carRequestModel.getNr_usi(), carRequestModel.getCc(), options);
        newCar = carRepository.save(newCar);
        return new CarResponseModel(newCar.getId(), newCar.getBrand(), newCar.getModel(), newCar.getVin(), newCar.getHp(), newCar.getCarburant(), newCar.getNr_usi(), newCar.getCc(), newCar.getOptions().getId(), newCar.getOptions().getWheels(), newCar.getOptions().getBodykit(), newCar.getOptions().getExhaust(), newCar.getOptions().getColor());
    }
    /*public List<Car> getAllByModel(String model){ return carRepository.findAllByModel(model);}

    public List<Car> getByHp(int hp){
        return carRepository.findByHp(hp);
    }

    public List<Car> getByCarburant(String carburant){
        return carRepository.findByCarburant(carburant);
    }

    public Car getByNumberplate(String numberplate) {
        return carRepository.findByNumberplate(numberplate);
    }*/
}
