package com.wtzconsult.demo.restcontroller;

import com.wtzconsult.demo.models.CarRequestModel;
import com.wtzconsult.demo.service.CarService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/car")

public class CarController {

    private final CarService carService;

    @PostMapping("/createWithBody")
    public ResponseEntity<?> createCarWithBody(@RequestBody CarRequestModel carRequestModel) {
        try{
            return  ResponseEntity.ok(carService.createCarWithBody(carRequestModel));
        }catch (Exception e){
//            return ResponseEntity.notFound().build();
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
    /*@GetMapping("/getAllByModel")
    public ResponseEntity<?> getAllByModel(@RequestParam String model) {
        return ResponseEntity.ok(carService.getAllByModel(model));
    }

    @GetMapping("/getByHp")
    public ResponseEntity<?> getByHp(@RequestParam int hp) {
        return ResponseEntity.ok(carService.getByHp(hp));
    }

    @GetMapping("/getByCarburant")
    public ResponseEntity<?> getByCarburant(@RequestParam String carburant) {
        return ResponseEntity.ok(carService.getByCarburant(carburant));
    }*/

}