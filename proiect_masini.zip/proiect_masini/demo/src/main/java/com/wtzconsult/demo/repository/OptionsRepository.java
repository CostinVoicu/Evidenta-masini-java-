package com.wtzconsult.demo.repository;

import com.wtzconsult.demo.bo.Options;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OptionsRepository extends JpaRepository<Options, Long> {
    default Options findOptionsByIdOrElseThrow(Long optionsId) {
        return findById(optionsId).orElseThrow(() -> new RuntimeException("Cannot found options with Id:" + optionsId.toString()));
    }
}
