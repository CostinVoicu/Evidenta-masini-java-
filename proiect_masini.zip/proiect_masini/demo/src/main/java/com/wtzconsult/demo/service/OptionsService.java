package com.wtzconsult.demo.service;

import com.wtzconsult.demo.bo.Options;
import com.wtzconsult.demo.repository.OptionsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OptionsService {

    private final OptionsRepository optionsRepository;

    public  Options createOptionsWithBody(Options options){

        Options newOptions = new Options(null, options.getWheels(), options.getBodykit(), options.getExhaust(), options.getColor());

        newOptions = optionsRepository.save(newOptions);
        return newOptions;
    }

    /*public List<Options> getAllByOptions(String exhaust)
    {
        return optionsRepository.findAllByExhaust(exhaust);
    }*/
}
