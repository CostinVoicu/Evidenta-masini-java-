package com.wtzconsult.demo.repository;

import com.wtzconsult.demo.bo.Car;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.Id;
import java.util.List;

@Repository
public interface CarRepository  extends JpaRepository<Car, Long> {
    /*
    List<Car> findAllByModel(String model);

    List<Car> findByHp(int hp);

    List<Car> findByCarburant(String carburant);
    Car findByNumberplate(String numberplate);
    */
}
